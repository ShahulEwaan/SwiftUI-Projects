//
//  RestartApp.swift
//  Restart
//
//  Created by SHAHUL HAMEED on 15/12/23.
//

import SwiftUI

@main
struct RestartApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
