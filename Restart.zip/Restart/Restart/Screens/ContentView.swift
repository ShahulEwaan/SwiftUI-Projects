//
//  ContentView.swift
//  Restart
//
//  Created by SHAHUL HAMEED on 15/12/23.
//

import SwiftUI

struct ContentView: View {
    // MARK:  - Property
    @AppStorage("onBoarding") var isOnboardingViewActive: Bool = true
    
    // MARK:  - BODY
    var body: some View {
        ZStack{
            if isOnboardingViewActive {
                OnboardingView()
            } else{
                HomeView()
            }
        }
    }
}

#Preview {
    ContentView()
        .previewDevice("iPhone 13")
    }
