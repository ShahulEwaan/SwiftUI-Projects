//
//  HomeView.swift
//  Restart
//
//  Created by SHAHUL HAMEED on 04/01/24.
//

import SwiftUI

struct HomeView: View {
    // MARK:  - Property
    @AppStorage("onBoarding") var isOnboardingViewActive: Bool = true
    @State private var isAnimating: Bool = false
    
    // MARK:  - BODY
    var body: some View {
        VStack(spacing: 20) {
            // MARK:  - HEADER
            Spacer()
            ZStack {
                CircleGroupView(shapeColor: .gray, shapeOpacity: 0.1)
                Image("character-2")
                    .resizable()
                    .scaledToFit()
                    .padding()
                    .offset(y: isAnimating ? 35 : -35)
                    .animation(.easeInOut(duration: 4) .repeatForever(), value: isAnimating)
            }
            // MARK: - CENTER
            Text("The time that leeds to mastery is depend on the intensity  of our focus.")
                .font(.title3)
                .fontWeight(.light)
                .foregroundStyle(.secondary )
                .multilineTextAlignment(.center)
            
            // MARK: - FOOTER
            Spacer()
            Button(action: {
                withAnimation {
                    playSound(sound: "success", type: "m4a ")
                    isOnboardingViewActive = true
                }
                
            }, label: {
                Image(systemName: "arrow.triangle.2.circlepath.circle.fill")
                    .imageScale(.large)
                Text("Restart")
                    .font(.system(.title3,design: .rounded))
                    .fontWeight(.bold)
            })//: BUTTON
            .buttonStyle(.borderedProminent)
            .controlSize(.large)
            .buttonBorderShape(.capsule )
            
        }
        .onAppear(perform: {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5 ) {
                isAnimating = true
            }
        })
        //: VSTACK
    }
}

#Preview {
    HomeView()
}
